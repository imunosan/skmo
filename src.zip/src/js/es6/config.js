var frontJs = {};

frontJs.breakpoints = {
    xl: 1280,
    lg: 1024,
    md: 600,
    sm: 320,
    //xs: 320
}