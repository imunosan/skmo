var frontJs = {};

frontJs.breakpoints = {
    xl: 1440,
    lg: 1280,
    md: 1024,
    sm: 768,
    xs: 480
}