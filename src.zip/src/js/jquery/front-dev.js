// document ready
$(document).ready(function() {
    componentDefault.init();
});